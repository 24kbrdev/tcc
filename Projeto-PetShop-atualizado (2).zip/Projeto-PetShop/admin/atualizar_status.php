<?php
session_start();
require_once __DIR__ . '/../conexao/conexao.php';

if (empty($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$id     = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
$status = $_POST['status'] ?? '';

$statusValidos = ['agendado', 'cancelado', 'concluido'];

if ($id && in_array($status, $statusValidos, true)) {
    $stmt = $pdo->prepare("UPDATE agendamentos SET status = ? WHERE id = ?");
    $stmt->execute([$status, $id]);
}

header('Location: dashboard.php');
exit;
