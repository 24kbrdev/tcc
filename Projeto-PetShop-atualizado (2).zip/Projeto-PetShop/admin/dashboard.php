<?php
session_start();
require_once __DIR__ . '/../conexao/conexao.php';

if (empty($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

// ---------- Filtros (opcionais) ----------
$filtroData   = $_GET['data'] ?? '';
$filtroStatus = $_GET['status'] ?? '';

$sql = "
    SELECT
        a.id, a.codigo, a.data_agendamento, a.horario, a.status,
        p.nome AS pet_nome, p.tipo_pet,
        u.nome AS tutor_nome, c.telefone,
        GROUP_CONCAT(s.nome SEPARATOR ', ') AS servicos_nomes,
        SUM(s.preco) AS total_preco
    FROM agendamentos a
    JOIN pets p                    ON p.id = a.id_pet
    JOIN clientes c                ON c.id = p.id_cliente
    JOIN usuarios u                ON u.id = c.id_usuario
    JOIN agendamento_servicos ags  ON ags.id_agendamento = a.id
    JOIN servicos s                ON s.id = ags.id_servico
    WHERE 1 = 1
";
$params = [];

if ($filtroData !== '') {
    $sql .= " AND a.data_agendamento = ?";
    $params[] = $filtroData;
}
if ($filtroStatus !== '') {
    $sql .= " AND a.status = ?";
    $params[] = $filtroStatus;
}

$sql .= " GROUP BY a.id ORDER BY a.data_agendamento DESC, a.horario DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$agendamentos = $stmt->fetchAll();

// ---------- Números rápidos do topo ----------
$totalHoje = $pdo->query(
    "SELECT COUNT(*) FROM agendamentos WHERE data_agendamento = CURDATE() AND status <> 'cancelado'"
)->fetchColumn();

$totalMes = $pdo->query(
    "SELECT COUNT(*) FROM agendamentos
     WHERE MONTH(data_agendamento) = MONTH(CURDATE())
       AND YEAR(data_agendamento) = YEAR(CURDATE())
       AND status <> 'cancelado'"
)->fetchColumn();

$faturamentoMes = $pdo->query(
    "SELECT COALESCE(SUM(s.preco), 0)
     FROM agendamentos a
     JOIN agendamento_servicos ags ON ags.id_agendamento = a.id
     JOIN servicos s ON s.id = ags.id_servico
     WHERE MONTH(a.data_agendamento) = MONTH(CURDATE())
       AND YEAR(a.data_agendamento) = YEAR(CURDATE())
       AND a.status = 'concluido'"
)->fetchColumn();

$rotulosStatus = [
    'agendado'  => 'Agendado',
    'cancelado' => 'Cancelado',
    'concluido' => 'Concluído',
];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel do administrador</title>
    <link rel="stylesheet" href="../assets/css/base.css">
    <link rel="stylesheet" href="admin.css">
</head>
<body>

<div class="topo topo-admin">
    <h1>Olá, <?= htmlspecialchars($_SESSION['admin_nome']) ?></h1>
    <a href="logout.php" class="sair">Sair</a>
</div>

<div class="container-dashboard">

    <div class="cartoes-resumo">
        <div class="cartao-resumo">
            <span class="numero"><?= (int) $totalHoje ?></span>
            <span class="rotulo">Agendamentos hoje</span>
        </div>
        <div class="cartao-resumo">
            <span class="numero"><?= (int) $totalMes ?></span>
            <span class="rotulo">Agendamentos no mês</span>
        </div>
        <div class="cartao-resumo">
            <span class="numero">R$ <?= number_format($faturamentoMes, 2, ',', '.') ?></span>
            <span class="rotulo">Faturado no mês (concluídos)</span>
        </div>
    </div>

    <form method="get" class="filtros">
        <input type="date" name="data" value="<?= htmlspecialchars($filtroData) ?>">
        <select name="status">
            <option value="">Todos os status</option>
            <?php foreach ($rotulosStatus as $valor => $rotulo): ?>
                <option value="<?= $valor ?>" <?= $filtroStatus === $valor ? 'selected' : '' ?>>
                    <?= $rotulo ?>
                </option>
            <?php endforeach; ?>
        </select>
        <button type="submit">Filtrar</button>
        <a href="dashboard.php" class="limpar">Limpar</a>
    </form>

    <div class="tabela-wrap">
        <table class="tabela-agendamentos">
            <thead>
                <tr>
                    <th>Código</th>
                    <th>Data</th>
                    <th>Hora</th>
                    <th>Pet</th>
                    <th>Tutor</th>
                    <th>Telefone</th>
                    <th>Serviços</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$agendamentos): ?>
                    <tr><td colspan="10" class="vazio">Nenhum agendamento encontrado.</td></tr>
                <?php endif; ?>

                <?php foreach ($agendamentos as $a): ?>
                    <tr>
                        <td><strong><?= htmlspecialchars($a['codigo']) ?></strong></td>
                        <td><?= date('d/m/Y', strtotime($a['data_agendamento'])) ?></td>
                        <td><?= substr($a['horario'], 0, 5) ?></td>
                        <td><?= htmlspecialchars($a['pet_nome']) ?> <small>(<?= htmlspecialchars($a['tipo_pet']) ?>)</small></td>
                        <td><?= htmlspecialchars($a['tutor_nome']) ?></td>
                        <td><?= htmlspecialchars($a['telefone']) ?></td>
                        <td><?= htmlspecialchars($a['servicos_nomes']) ?></td>
                        <td>R$ <?= number_format($a['total_preco'], 2, ',', '.') ?></td>
                        <td>
                            <span class="etiqueta etiqueta-<?= $a['status'] ?>">
                                <?= $rotulosStatus[$a['status']] ?>
                            </span>
                        </td>
                        <td>
                            <form method="post" action="atualizar_status.php" class="form-status">
                                <input type="hidden" name="id" value="<?= $a['id'] ?>">
                                <select name="status" onchange="this.form.submit()">
                                    <?php foreach ($rotulosStatus as $valor => $rotulo): ?>
                                        <option value="<?= $valor ?>" <?= $a['status'] === $valor ? 'selected' : '' ?>>
                                            <?= $rotulo ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
