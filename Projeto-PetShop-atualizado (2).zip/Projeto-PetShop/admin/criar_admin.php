<?php
/**
 * EXECUTE ESTA PÁGINA UMA ÚNICA VEZ para criar o primeiro administrador.
 * Depois disso, por segurança, apague este arquivo (ou pelo menos o
 * bloco de criação abaixo) para que ninguém mais consiga criar um
 * administrador só acessando a URL.
 */
require_once __DIR__ . '/../conexao/conexao.php';

$mensagem = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome  = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';

    if ($nome === '' || $email === '' || strlen($senha) < 6) {
        $mensagem = 'Preencha nome, e-mail e uma senha com pelo menos 6 caracteres.';
    } else {
        $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE email = ?");
        $stmt->execute([$email]);

        if ($stmt->fetch()) {
            $mensagem = 'Já existe um usuário com esse e-mail.';
        } else {
            $hash = password_hash($senha, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare(
                "INSERT INTO usuarios (nome, email, senha, tipo) VALUES (?, ?, ?, 'administrador')"
            );
            $stmt->execute([$nome, $email, $hash]);
            $mensagem = 'Administrador criado com sucesso! Você já pode fazer login.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Criar administrador</title>
    <link rel="stylesheet" href="../assets/css/base.css">
    <link rel="stylesheet" href="admin.css">
</head>
<body>

<div class="topo"><h1>Criar administrador</h1></div>

<div class="container-flow">
    <?php if ($mensagem): ?>
        <div class="mensagem-erro" style="background:#e6f4e6;color:#256428;">
            <?= htmlspecialchars($mensagem) ?>
        </div>
    <?php endif; ?>

    <form method="post" class="cartao-admin">
        <label class="campo">Nome
            <input type="text" name="nome" class="DD" required>
        </label>
        <label class="campo">E-mail
            <input type="email" name="email" class="DD" required>
        </label>
        <label class="campo">Senha
            <input type="password" name="senha" class="DD" required minlength="6">
        </label>
        <button type="submit" class="btn-principal ativo">Criar administrador</button>
    </form>

    <p style="text-align:center;font-size:13px;opacity:.7;">
        Depois de criar seu usuário, apague este arquivo (criar_admin.php).
    </p>
</div>

</body>
</html>
