<?php
session_start();
require_once __DIR__ . '/../conexao/conexao.php';

if (!empty($_SESSION['admin_id'])) {
    header('Location: dashboard.php');
    exit;
}

$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';

    $stmt = $pdo->prepare("SELECT id, nome, senha FROM usuarios WHERE email = ? AND tipo = 'administrador'");
    $stmt->execute([$email]);
    $admin = $stmt->fetch();

    if ($admin && password_verify($senha, $admin['senha'])) {
        $_SESSION['admin_id']   = $admin['id'];
        $_SESSION['admin_nome'] = $admin['nome'];
        header('Location: dashboard.php');
        exit;
    }

    $erro = 'E-mail ou senha inválidos.';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login administrador</title>
    <link rel="stylesheet" href="../assets/css/base.css">
    <link rel="stylesheet" href="admin.css">
</head>
<body>

<div class="topo"><h1>Área do administrador</h1></div>

<div class="container-flow">
    <?php if ($erro): ?>
        <div class="mensagem-erro"><?= htmlspecialchars($erro) ?></div>
    <?php endif; ?>

    <form method="post" class="cartao-admin">
        <label class="campo">E-mail
            <input type="email" name="email" class="DD" required autofocus>
        </label>
        <label class="campo">Senha
            <input type="password" name="senha" class="DD" required>
        </label>
        <button type="submit" class="btn-principal ativo">Entrar</button>
    </form>

    <p style="text-align:center;font-size:13px;">
        <a href="../pageinicio/index.php">&larr; Voltar para o site</a>
    </p>
</div>

</body>
</html>
