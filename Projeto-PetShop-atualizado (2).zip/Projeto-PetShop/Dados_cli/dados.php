<?php
session_start();

// Não deixa chegar aqui sem antes ter escolhido ao menos um serviço.
if (empty($_SESSION['agendamento']['servicos'])) {
    header('Location: ../pageagenda/agenda.php');
    exit;
}

$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $petNome  = trim($_POST['pet'] ?? '');
    $petTipo  = trim($_POST['tipo'] ?? '');
    $tutor    = trim($_POST['tutor'] ?? '');
    $telefone = preg_replace('/\D/', '', $_POST['telefone'] ?? '');

    if ($petNome === '' || $petTipo === '' || $tutor === '' || strlen($telefone) < 10) {
        $erro = 'Preencha todos os campos corretamente (telefone com DDD).';
    } else {
        $_SESSION['agendamento']['pet_nome']  = $petNome;
        $_SESSION['agendamento']['pet_tipo']  = $petTipo;
        $_SESSION['agendamento']['tutor']     = $tutor;
        $_SESSION['agendamento']['telefone']  = $telefone;

        header('Location: ../time/time.php');
        exit;
    }
}

// Mantém os campos preenchidos se o usuário voltar a esta página.
$valores = $_SESSION['agendamento'] ?? [];

$passoAtual = 2;
$linkVoltar = '../pageagenda/agenda.php';
$tituloTopo = 'Agendamento';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dados do pet e tutor</title>
    <link rel="stylesheet" href="../assets/css/base.css">
    <link rel="stylesheet" href="styleD.css">
</head>
<body>

<?php require __DIR__ . '/../includes/header_passos.php'; ?>

<form method="post" class="container-flow" id="formulario2">
    <h2 class="titulo-etapa">Dados do pet e tutor</h2>

    <?php if ($erro): ?>
        <div class="mensagem-erro"><?= htmlspecialchars($erro) ?></div>
    <?php endif; ?>

    <label class="campo">
        Nome do pet
        <input type="text" name="pet" placeholder="Ex: Rex" class="DD"
               value="<?= htmlspecialchars($valores['pet_nome'] ?? '') ?>">
    </label>

    <label class="campo">
        Tipo do pet
        <input type="text" name="tipo" placeholder="Ex: Cachorro ou gato" class="DD"
               value="<?= htmlspecialchars($valores['pet_tipo'] ?? '') ?>">
    </label>

    <label class="campo">
        Nome do tutor
        <input type="text" name="tutor" placeholder="Seu nome completo" class="DD"
               value="<?= htmlspecialchars($valores['tutor'] ?? '') ?>">
    </label>

    <label class="campo">
        Telefone
        <input type="tel" name="telefone" placeholder="(11) 99999-9999" class="DD"
               maxlength="11" oninput="this.value=this.value.replace(/\D/g,'')"
               value="<?= htmlspecialchars($valores['telefone'] ?? '') ?>">
    </label>

    <button type="submit" class="btn-principal" id="continuar">Continuar</button>
</form>

<script src="dados.js"></script>
</body>
</html>
