const campos = document.querySelectorAll('.DD');
const botaoContinuar = document.getElementById('continuar');

function verificarCampos() {
    let preenchidos = true;

    campos.forEach(campo => {
        if (campo.value.trim() === '') {
            preenchidos = false;
        }
    });

    botaoContinuar.disabled = !preenchidos;
    botaoContinuar.classList.toggle('ativo', preenchidos);
}

campos.forEach(campo => campo.addEventListener('input', verificarCampos));

// Verifica logo ao carregar (caso os campos já venham preenchidos,
// por exemplo quando o usuário volta para esta página).
verificarCampos();
