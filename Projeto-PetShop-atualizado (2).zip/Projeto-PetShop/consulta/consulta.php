<?php
session_start();
require_once __DIR__ . '/../conexao/conexao.php';

$erro = '';
$mensagem = '';
$agendamento = null;

$telefone = preg_replace('/\D/', '', $_POST['telefone'] ?? $_GET['telefone'] ?? '');
$codigo   = trim($_POST['codigo'] ?? $_GET['codigo'] ?? '');

/**
 * Busca um agendamento pelo código + telefone (é essa dupla checagem
 * que funciona como "senha" simples para o cliente acessar só o
 * próprio agendamento, sem precisar de login).
 */
function buscarAgendamento(PDO $pdo, string $codigo, string $telefone): array|false
{
    $stmt = $pdo->prepare("
        SELECT a.id, a.codigo, a.data_agendamento, a.horario, a.status,
               p.nome AS pet_nome, u.nome AS tutor_nome
        FROM agendamentos a
        JOIN pets p     ON p.id = a.id_pet
        JOIN clientes c ON c.id = p.id_cliente
        JOIN usuarios u ON u.id = c.id_usuario
        WHERE a.codigo = ? AND c.telefone = ?
    ");
    $stmt->execute([$codigo, $telefone]);
    return $stmt->fetch();
}

// ---------- Ação de cancelar ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancelar'])) {
    $agendamento = buscarAgendamento($pdo, $codigo, $telefone);

    if (!$agendamento) {
        $erro = 'Agendamento não encontrado. Confira o telefone e o código.';
    } elseif ($agendamento['status'] !== 'agendado') {
        $erro = 'Este agendamento já não está mais ativo.';
    } else {
        $stmt = $pdo->prepare("UPDATE agendamentos SET status = 'cancelado' WHERE id = ?");
        $stmt->execute([$agendamento['id']]);
        $mensagem = 'Agendamento cancelado com sucesso.';
        $agendamento['status'] = 'cancelado';
    }
}
// ---------- Ação de consultar ----------
elseif ($_SERVER['REQUEST_METHOD'] === 'POST' || ($telefone && $codigo)) {
    if (strlen($telefone) < 10 || $codigo === '') {
        $erro = 'Informe o telefone (com DDD) e o código de confirmação.';
    } else {
        $agendamento = buscarAgendamento($pdo, $codigo, $telefone);
        if (!$agendamento) {
            $erro = 'Nenhum agendamento encontrado com esses dados.';
        }
    }
}

// Busca os serviços do agendamento encontrado (pode ter mais de um).
$servicosDoAgendamento = [];
if ($agendamento) {
    $stmt = $pdo->prepare("
        SELECT s.nome, s.preco
        FROM agendamento_servicos ags
        JOIN servicos s ON s.id = ags.id_servico
        WHERE ags.id_agendamento = ?
    ");
    $stmt->execute([$agendamento['id']]);
    $servicosDoAgendamento = $stmt->fetchAll();
}

$rotulosStatus = [
    'agendado'  => 'Agendado',
    'cancelado' => 'Cancelado',
    'concluido' => 'Concluído',
];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consultar agendamento</title>
    <link rel="stylesheet" href="../assets/css/base.css">
    <link rel="stylesheet" href="consulta.css">
</head>
<body>

<div class="topo">
    <span class="voltar" onclick="window.location.href='../pageinicio/index.php'">
        <img src="../pageagenda/voltar.png" alt="Voltar" width="26px">
    </span>
    <h1>Consultar agendamento</h1>
</div>

<div class="container-flow">

    <form method="post" class="cartao-consulta">
        <label class="campo">Telefone cadastrado
            <input type="tel" name="telefone" class="DD" maxlength="11"
                   oninput="this.value=this.value.replace(/\D/g,'')"
                   value="<?= htmlspecialchars($telefone) ?>" required>
        </label>
        <label class="campo">Código de confirmação
            <input type="text" name="codigo" class="DD" maxlength="6"
                   value="<?= htmlspecialchars($codigo) ?>" required>
        </label>
        <button type="submit" class="btn-principal ativo">Consultar</button>
    </form>

    <?php if ($erro): ?>
        <div class="mensagem-erro"><?= htmlspecialchars($erro) ?></div>
    <?php endif; ?>

    <?php if ($mensagem): ?>
        <div class="mensagem-sucesso"><?= htmlspecialchars($mensagem) ?></div>
    <?php endif; ?>

    <?php if ($agendamento): ?>
        <div class="cartao-resultado">
            <span class="etiqueta etiqueta-<?= $agendamento['status'] ?>">
                <?= $rotulosStatus[$agendamento['status']] ?>
            </span>

            <p><strong>Pet:</strong> <?= htmlspecialchars($agendamento['pet_nome']) ?></p>
            <p><strong>Tutor:</strong> <?= htmlspecialchars($agendamento['tutor_nome']) ?></p>
            <p><strong>Data:</strong> <?= date('d/m/Y', strtotime($agendamento['data_agendamento'])) ?></p>
            <p><strong>Horário:</strong> <?= substr($agendamento['horario'], 0, 5) ?></p>
            <p><strong>Serviços:</strong>
                <?= htmlspecialchars(implode(', ', array_column($servicosDoAgendamento, 'nome'))) ?>
            </p>
            <p><strong>Total:</strong>
                R$ <?= number_format(array_sum(array_column($servicosDoAgendamento, 'preco')), 2, ',', '.') ?>
            </p>

            <?php if ($agendamento['status'] === 'agendado'): ?>
                <form method="post" onsubmit="return confirm('Tem certeza que deseja cancelar este agendamento?');">
                    <input type="hidden" name="telefone" value="<?= htmlspecialchars($telefone) ?>">
                    <input type="hidden" name="codigo" value="<?= htmlspecialchars($codigo) ?>">
                    <button type="submit" name="cancelar" value="1" class="btn-cancelar">
                        Cancelar agendamento
                    </button>
                </form>
            <?php endif; ?>
        </div>
    <?php endif; ?>

</div>

</body>
</html>
