# Projeto PetShop - TCC

Site de agendamento para petshop, com painel administrativo para
gerenciar os agendamentos.

## O que mudou nesta versão

- **Visual renovado**: paleta e tipografia consistentes em todas as
  páginas, layout responsivo, cartões com sombra em vez de tabelas.
- **Fluxo conectado**: a escolha do serviço, os dados do pet/tutor e o
  horário agora passam de uma página para outra usando sessão do PHP
  (antes cada página "esquecia" o que foi preenchido nas anteriores).
- **Banco de dados realmente integrado**: ao confirmar o horário, o
  agendamento é gravado nas tabelas `usuarios`, `clientes`, `pets` e
  `agendamentos`, dentro de uma transação. A tela de horários também
  consulta o banco para desabilitar horários já ocupados no dia.
- **Painel do administrador** (`/admin`): login, lista de todos os
  agendamentos com filtro por data/status, alteração de status
  (agendado / concluído / cancelado) e alguns números rápidos
  (agendamentos do dia, do mês, faturamento do mês).
- **Vários serviços por agendamento**: na tela de serviços agora dá
  pra marcar mais de um (ex: Banho + Corte de unha) no mesmo horário.
- **Código de confirmação**: ao concluir, o cliente recebe um código
  de 4 dígitos (com botão de copiar) e é avisado para guardá-lo.
- **Descrição dos serviços na página inicial**: ao clicar em um
  serviço, abre (com animação suave) um texto curto e o aviso para
  clicar em "Agendar agora". Os textos ficam na coluna `descricao` da
  tabela `servicos`, então dá para editá-los direto no banco.
- **Consultar/cancelar agendamento** (`/consulta`): na página inicial,
  o cliente informa o telefone cadastrado + o código e consegue ver o
  status do agendamento e cancelá-lo, sem precisar de login.
- **Conexão com PDO** em vez de `mysqli`, usando *prepared statements*
  (mais seguro contra SQL Injection) e com o schema corrigido (senha
  agora guarda um hash, não texto puro).

## Como rodar no WAMP

1. Copie a pasta `Projeto-PetShop` inteira para `C:\wamp64\www\`.
2. Ligue o WAMP e abra o phpMyAdmin (ou o console do MySQL).
3. Importe o arquivo `database/petshop.sql` (ele cria o banco
   `petshop` e a tabela de serviços já vem com alguns exemplos).
4. Acesse `http://localhost/Projeto-PetShop/admin/criar_admin.php`
   e crie seu usuário administrador (nome, e-mail e senha).
   **Depois disso, apague esse arquivo** (`criar_admin.php`) - ele
   existe só para criar o primeiro administrador com segurança.
5. Acesse `http://localhost/Projeto-PetShop/pageinicio/index.php`
   para ver o site, e `http://localhost/Projeto-PetShop/admin/login.php`
   para entrar no painel administrativo.

## Estrutura de pastas

```
Projeto-PetShop/
├── database/petshop.sql       -> schema do banco
├── conexao/conexao.php        -> conexão PDO (usada por todas as páginas)
├── assets/css/base.css        -> estilos compartilhados
├── includes/header_passos.php -> cabeçalho com os "passos 1-2-3" reutilizado
├── pageinicio/                -> página inicial (lista de serviços)
├── pageagenda/                -> passo 1: escolher serviço
├── Dados_cli/                 -> passo 2: dados do pet e tutor
├── time/                      -> passo 3: escolher data/horário e salvar
├── confirmacao/                -> tela final de confirmação (com o código)
├── consulta/                   -> cliente consulta/cancela pelo telefone + código
└── admin/                     -> login, dashboard e criação do 1º admin
```

## Possíveis próximos passos (ideias para você continuar)

- Login de cliente (hoje cada agendamento cria um usuário novo).
- Enviar o código de confirmação por WhatsApp/e-mail automaticamente
  (hoje o cliente só vê na tela e precisa copiar/guardar).
- Editar/cadastrar serviços pelo próprio painel administrativo, sem
  precisar mexer direto no banco.
- Pagamento online (não incluído nesta versão - só agendamento).
