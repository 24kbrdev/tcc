const campoData = document.getElementById('data');
const campoHorario = document.getElementById('horario');
const botoesHora = document.querySelectorAll('.hora');
const botaoConfirmar = document.getElementById('confirmar');

// Não deixa escolher uma data no passado.
const hoje = new Date();
const ano = hoje.getFullYear();
const mes = String(hoje.getMonth() + 1).padStart(2, '0');
const dia = String(hoje.getDate()).padStart(2, '0');
campoData.min = `${ano}-${mes}-${dia}`;

function atualizarBotaoConfirmar() {
    const pronto = campoData.value !== '' && campoHorario.value !== '';
    botaoConfirmar.disabled = !pronto;
    botaoConfirmar.classList.toggle('ativo', pronto);
}

botoesHora.forEach(botao => {
    botao.addEventListener('click', () => {
        botoesHora.forEach(b => b.classList.remove('ativo'));
        botao.classList.add('ativo');
        campoHorario.value = botao.dataset.hora;
        atualizarBotaoConfirmar();
    });
});

// Ao trocar a data, recarrega a página levando a data pela URL para o
// servidor calcular quais horários já estão ocupados naquele dia.
campoData.addEventListener('change', () => {
    const url = new URL(window.location.href);
    url.searchParams.set('data', campoData.value);
    window.location.href = url.toString();
});

atualizarBotaoConfirmar();
