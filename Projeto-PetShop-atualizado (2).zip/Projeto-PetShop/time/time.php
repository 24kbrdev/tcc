<?php
session_start();
require_once __DIR__ . '/../conexao/conexao.php';

if (empty($_SESSION['agendamento']['servicos']) || empty($_SESSION['agendamento']['pet_nome'])) {
    header('Location: ../pageagenda/agenda.php');
    exit;
}

// Busca os serviços escolhidos para mostrar um resumo e calcular o total.
$idsServicos = $_SESSION['agendamento']['servicos'];
$marcadores  = implode(',', array_fill(0, count($idsServicos), '?'));
$stmt = $pdo->prepare("SELECT nome, preco FROM servicos WHERE id IN ($marcadores)");
$stmt->execute($idsServicos);
$servicosEscolhidos = $stmt->fetchAll();
$totalPreco = array_sum(array_column($servicosEscolhidos, 'preco'));

$horariosDisponiveis = ['08:00', '09:00', '10:00', '11:00', '13:00', '14:00', '15:00', '16:00', '17:00'];
$erro = '';

/**
 * Gera um código curto (4 dígitos) e garante que ele ainda não existe
 * no banco, tentando de novo em caso de colisão.
 */
function gerarCodigoUnico(PDO $pdo): string
{
    do {
        $codigo = (string) random_int(1000, 9999);
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM agendamentos WHERE codigo = ?");
        $stmt->execute([$codigo]);
    } while ($stmt->fetchColumn() > 0);

    return $codigo;
}

// ------------------------------------------------------------
// Envio do formulário: grava o agendamento (e todos os serviços
// escolhidos) no banco de dados e gera o código de confirmação.
// ------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data    = $_POST['data'] ?? '';
    $horario = $_POST['horario'] ?? '';
    $hoje    = date('Y-m-d');

    if ($data < $hoje || !in_array($horario, $horariosDisponiveis, true)) {
        $erro = 'Escolha uma data e um horário válidos.';
    } else {
        $ag = $_SESSION['agendamento'];

        try {
            $pdo->beginTransaction();

            // 1) Usuário (cliente) - cria um novo a cada agendamento,
            //    já que o site ainda não tem login de cliente.
            $emailGerado = 'cliente_' . uniqid() . '@petshop.local';
            $stmt = $pdo->prepare(
                "INSERT INTO usuarios (nome, email, senha, tipo) VALUES (?, ?, ?, 'cliente')"
            );
            $stmt->execute([$ag['tutor'], $emailGerado, password_hash(uniqid(), PASSWORD_DEFAULT)]);
            $idUsuario = $pdo->lastInsertId();

            // 2) Cliente
            $stmt = $pdo->prepare("INSERT INTO clientes (id_usuario, telefone) VALUES (?, ?)");
            $stmt->execute([$idUsuario, $ag['telefone']]);
            $idCliente = $pdo->lastInsertId();

            // 3) Pet
            $stmt = $pdo->prepare("INSERT INTO pets (id_cliente, nome, tipo_pet) VALUES (?, ?, ?)");
            $stmt->execute([$idCliente, $ag['pet_nome'], $ag['pet_tipo']]);
            $idPet = $pdo->lastInsertId();

            // 4) Verifica de novo, dentro da transação, se o horário não foi
            //    ocupado por outra pessoa entre o carregamento da página e o envio.
            $stmt = $pdo->prepare(
                "SELECT COUNT(*) FROM agendamentos
                 WHERE data_agendamento = ? AND horario = ? AND status <> 'cancelado'"
            );
            $stmt->execute([$data, $horario]);

            if ($stmt->fetchColumn() > 0) {
                $pdo->rollBack();
                $erro = 'Esse horário acabou de ser reservado por outra pessoa. Escolha outro.';
            } else {
                // 5) Agendamento, com um código curto de confirmação
                $codigo = gerarCodigoUnico($pdo);

                $stmt = $pdo->prepare(
                    "INSERT INTO agendamentos (id_pet, codigo, data_agendamento, horario, status)
                     VALUES (?, ?, ?, ?, 'agendado')"
                );
                $stmt->execute([$idPet, $codigo, $data, $horario]);
                $idAgendamento = $pdo->lastInsertId();

                // 6) Um ou mais serviços vinculados a este agendamento
                $stmtServico = $pdo->prepare(
                    "INSERT INTO agendamento_servicos (id_agendamento, id_servico) VALUES (?, ?)"
                );
                foreach ($ag['servicos'] as $idServico) {
                    $stmtServico->execute([$idAgendamento, $idServico]);
                }

                $pdo->commit();

                $_SESSION['ultimo_agendamento'] = [
                    'codigo'   => $codigo,
                    'pet'      => $ag['pet_nome'],
                    'tutor'    => $ag['tutor'],
                    'data'     => $data,
                    'horario'  => $horario,
                ];
                unset($_SESSION['agendamento']);

                header('Location: ../confirmacao/confirmacao.php');
                exit;
            }
        } catch (Exception $e) {
            $pdo->rollBack();
            $erro = 'Não foi possível concluir o agendamento. Tente novamente.';
        }
    }
}

// ------------------------------------------------------------
// Horários já ocupados na data escolhida (para desabilitar os
// botões correspondentes e evitar escolher um horário indisponível).
// ------------------------------------------------------------
$dataConsultada = $_GET['data'] ?? $_POST['data'] ?? '';
$horariosOcupados = [];

if ($dataConsultada !== '') {
    $stmt = $pdo->prepare(
        "SELECT TIME_FORMAT(horario, '%H:%i') AS horario FROM agendamentos
         WHERE data_agendamento = ? AND status <> 'cancelado'"
    );
    $stmt->execute([$dataConsultada]);
    $horariosOcupados = array_column($stmt->fetchAll(), 'horario');
}

$passoAtual = 3;
$linkVoltar = '../Dados_cli/dados.php';
$tituloTopo = 'Agendamento';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Escolher data e horário</title>
    <link rel="stylesheet" href="../assets/css/base.css">
    <link rel="stylesheet" href="time.css">
</head>
<body>

<?php require __DIR__ . '/../includes/header_passos.php'; ?>

<form method="post" class="container-flow" id="formHorario">
    <h2 class="titulo-etapa">Escolha o dia e o horário</h2>

    <div class="resumo-servicos">
        <?php foreach ($servicosEscolhidos as $s): ?>
            <span class="chip"><?= htmlspecialchars($s['nome']) ?></span>
        <?php endforeach; ?>
        <strong class="total-chip">Total: R$ <?= number_format($totalPreco, 2, ',', '.') ?></strong>
    </div>

    <?php if ($erro): ?>
        <div class="mensagem-erro"><?= htmlspecialchars($erro) ?></div>
    <?php endif; ?>

    <input type="date" name="data" id="data" class="campo-data" value="<?= htmlspecialchars($dataConsultada) ?>" required>
    <input type="hidden" name="horario" id="horario">

    <div class="grade-horarios">
        <?php foreach ($horariosDisponiveis as $h): ?>
            <button
                type="button"
                class="hora"
                data-hora="<?= $h ?>"
                <?= in_array($h, $horariosOcupados, true) ? 'disabled' : '' ?>
            ><?= $h ?></button>
        <?php endforeach; ?>
    </div>

    <button type="submit" class="btn-principal" id="confirmar">Confirmar agendamento</button>
</form>

<script src="time.js"></script>
</body>
</html>
