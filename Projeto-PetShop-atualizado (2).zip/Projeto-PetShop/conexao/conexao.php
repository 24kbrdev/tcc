<?php
/**
 * Conexão com o banco de dados usando PDO.
 *
 * Usar PDO (em vez do mysqli antigo) permite "prepared statements",
 * que é a forma correta de evitar SQL Injection: os valores digitados
 * pelo usuário nunca são colados direto na query.
 *
 * Qualquer página que precise do banco deve fazer:
 *   require_once __DIR__ . '/../conexao/conexao.php';
 * e depois usar a variável $pdo.
 */

$host   = "localhost";
$usuario = "root";
$senha   = "";
$banco   = "petshop";

try {
    $pdo = new PDO(
        "mysql:host={$host};dbname={$banco};charset=utf8mb4",
        $usuario,
        $senha,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    // Em produção não se deve mostrar o erro real na tela, mas para o TCC
    // (ambiente local) isso ajuda a identificar problemas de configuração.
    http_response_code(500);
    die("Erro ao conectar no banco de dados: " . $e->getMessage());
}
