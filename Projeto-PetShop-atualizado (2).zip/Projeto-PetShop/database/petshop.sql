-- ============================================================
-- Banco de dados do PetShop - TCC
-- ============================================================

CREATE DATABASE IF NOT EXISTS petshop
  CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

USE petshop;

-- ------------------------------------------------------------
-- Usuários (clientes e administradores)
-- ------------------------------------------------------------
CREATE TABLE usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  senha VARCHAR(255) NOT NULL,          -- guarda o HASH da senha (password_hash), não a senha em texto puro
  tipo ENUM('cliente', 'administrador') NOT NULL DEFAULT 'cliente',
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ------------------------------------------------------------
-- Dados extras dos clientes
-- ------------------------------------------------------------
CREATE TABLE clientes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  id_usuario INT NOT NULL,
  telefone VARCHAR(20) NOT NULL,
  FOREIGN KEY (id_usuario) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- ------------------------------------------------------------
-- Pets de cada cliente
-- ------------------------------------------------------------
CREATE TABLE pets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  id_cliente INT NOT NULL,
  nome VARCHAR(100) NOT NULL,
  tipo_pet VARCHAR(100) NOT NULL,
  FOREIGN KEY (id_cliente) REFERENCES clientes(id) ON DELETE CASCADE
);

-- ------------------------------------------------------------
-- Serviços oferecidos
-- ------------------------------------------------------------
CREATE TABLE servicos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  preco DECIMAL(10,2) NOT NULL,
  duracao INT NOT NULL COMMENT 'duração em minutos',
  descricao VARCHAR(255) NULL COMMENT 'texto curto exibido na página inicial',
  ativo TINYINT(1) NOT NULL DEFAULT 1
);

-- ------------------------------------------------------------
-- Agendamentos
-- Cada agendamento pode ter mais de um serviço (ver tabela
-- agendamento_servicos abaixo). O "codigo" é o código curto que o
-- cliente recebe na confirmação e usa depois para consultar/cancelar.
-- ------------------------------------------------------------
CREATE TABLE agendamentos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  id_pet INT NOT NULL,
  codigo VARCHAR(6) NOT NULL UNIQUE,
  data_agendamento DATE NOT NULL,
  horario TIME NOT NULL,
  status ENUM('agendado', 'cancelado', 'concluido') NOT NULL DEFAULT 'agendado',
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (id_pet) REFERENCES pets(id) ON DELETE CASCADE
);

-- ------------------------------------------------------------
-- Serviços escolhidos em cada agendamento (relação N:N entre
-- agendamentos e servicos, já que agora dá pra escolher mais de um)
-- ------------------------------------------------------------
CREATE TABLE agendamento_servicos (
  id_agendamento INT NOT NULL,
  id_servico INT NOT NULL,
  PRIMARY KEY (id_agendamento, id_servico),
  FOREIGN KEY (id_agendamento) REFERENCES agendamentos(id) ON DELETE CASCADE,
  FOREIGN KEY (id_servico) REFERENCES servicos(id)
);

-- ------------------------------------------------------------
-- Serviços iniciais (os mesmos que já apareciam no site)
-- ------------------------------------------------------------
INSERT INTO servicos (nome, preco, duracao, descricao) VALUES
  ('Banho', 50.00, 40, 'Banho com shampoo adequado ao pelo do seu pet, secagem e perfume.'),
  ('Tosa', 60.00, 50, 'Tosa completa na máquina ou na tesoura, do jeitinho que você preferir.'),
  ('Corte de unha', 30.00, 15, 'Corte e lixa das unhas com todo cuidado, para o conforto do seu pet.'),
  ('Veterinário', 150.00, 30, 'Consulta clínica com veterinário para avaliar a saúde do seu pet.'),
  ('Banho e tosa', 100.00, 80, 'O combo completo: banho e tosa no mesmo horário.'),
  ('Tosa higiênica', 45.00, 30, 'Tosa nas áreas de higiene, mantendo seu pet limpo e confortável.');

-- ------------------------------------------------------------
-- Observação: o usuário administrador é criado depois, pela
-- página admin/criar_admin.php (para gerar a senha com hash
-- corretamente). Veja o README.
-- ------------------------------------------------------------
