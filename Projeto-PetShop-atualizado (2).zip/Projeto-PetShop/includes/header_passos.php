<?php
/**
 * Cabeçalho reutilizável do fluxo de agendamento (as 3 etapas).
 *
 * Antes de incluir este arquivo, defina:
 *   $passoAtual  -> 1, 2 ou 3
 *   $linkVoltar  -> para onde o botão "voltar" leva
 *   $tituloTopo  -> texto do título (opcional, padrão "Agendamento")
 */
$tituloTopo = $tituloTopo ?? 'Agendamento';
?>
<div class="topo">
  <span class="voltar" onclick="window.location.href='<?= htmlspecialchars($linkVoltar) ?>'">
    <img src="../pageagenda/voltar.png" alt="Voltar" width="26px">
  </span>
  <h1><?= htmlspecialchars($tituloTopo) ?></h1>
  <div class="passos">
    <div class="circulo <?= $passoAtual >= 1 ? 'atv' : '' ?>">1</div>
    <div class="circulo <?= $passoAtual >= 2 ? 'atv' : '' ?>">2</div>
    <div class="circulo <?= $passoAtual >= 3 ? 'atv' : '' ?>">3</div>
  </div>
</div>
