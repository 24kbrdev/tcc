const opcoes = document.querySelectorAll('input[name="servicos[]"]');
const botaoContinuar = document.getElementById('continuar');
const resumoTotal = document.getElementById('resumoTotal');
const qtdSelecionada = document.getElementById('qtdSelecionada');
const valorTotal = document.getElementById('valorTotal');

function atualizar() {
    const selecionados = document.querySelectorAll('input[name="servicos[]"]:checked');

    botaoContinuar.disabled = selecionados.length === 0;
    botaoContinuar.classList.toggle('ativo', selecionados.length > 0);

    if (selecionados.length === 0) {
        resumoTotal.hidden = true;
        return;
    }

    let total = 0;
    selecionados.forEach(opcao => {
        total += parseFloat(opcao.dataset.preco);
    });

    qtdSelecionada.textContent = selecionados.length === 1
        ? '1 serviço selecionado'
        : `${selecionados.length} serviços selecionados`;
    valorTotal.textContent = 'Total: R$ ' + total.toFixed(2).replace('.', ',');
    resumoTotal.hidden = false;
}

opcoes.forEach(opcao => opcao.addEventListener('change', atualizar));

atualizar();
