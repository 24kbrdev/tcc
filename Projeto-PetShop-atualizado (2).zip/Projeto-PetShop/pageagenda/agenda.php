<?php
session_start();
require_once __DIR__ . '/../conexao/conexao.php';

// Agora é possível escolher mais de um serviço no mesmo agendamento.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $idsServicos = $_POST['servicos'] ?? [];
    $idsServicos = array_filter(array_map('intval', $idsServicos));

    if ($idsServicos) {
        $_SESSION['agendamento']['servicos'] = array_values($idsServicos);
        header('Location: ../Dados_cli/dados.php');
        exit;
    }
}

$servicos = $pdo->query("SELECT id, nome, preco FROM servicos WHERE ativo = 1 ORDER BY id")->fetchAll();
$selecionadosAnteriores = $_SESSION['agendamento']['servicos'] ?? [];

// Vindo da página inicial (clique no aviso "Agendar agora" de um serviço),
// já deixa aquele serviço marcado, desde que ele exista e esteja ativo.
$servicoDaUrl = filter_input(INPUT_GET, 'servico', FILTER_VALIDATE_INT);
if ($servicoDaUrl && in_array($servicoDaUrl, array_column($servicos, 'id'))) {
    $selecionadosAnteriores = [$servicoDaUrl];
}

$passoAtual = 1;
$linkVoltar = '../pageinicio/index.php';
$tituloTopo = 'Agendamento';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Escolher serviço</title>
    <link rel="stylesheet" href="../assets/css/base.css">
    <link rel="stylesheet" href="style2.css">
</head>
<body>

<?php require __DIR__ . '/../includes/header_passos.php'; ?>

<form method="post" class="container-flow">
    <h2 class="titulo-etapa">Escolha um ou mais serviços:</h2>

    <div class="lista-servico">
        <?php foreach ($servicos as $servico): ?>
            <label class="opcao">
                <input
                    type="checkbox"
                    name="servicos[]"
                    value="<?= $servico['id'] ?>"
                    data-preco="<?= $servico['preco'] ?>"
                    <?= in_array($servico['id'], $selecionadosAnteriores) ? 'checked' : '' ?>
                    class="confirme"
                >
                <span class="titulo"><?= htmlspecialchars($servico['nome']) ?></span>
                <span class="preco">R$ <?= number_format($servico['preco'], 2, ',', '.') ?></span>
            </label>
        <?php endforeach; ?>
    </div>

    <div class="resumo-total" id="resumoTotal" hidden>
        <span id="qtdSelecionada"></span>
        <strong id="valorTotal"></strong>
    </div>

    <button type="submit" class="btn-principal" id="continuar">Continuar</button>
</form>

<script src="agenda.js"></script>
</body>
</html>
