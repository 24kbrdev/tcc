<?php
require_once __DIR__ . '/../conexao/conexao.php';

// Busca os serviços ativos direto do banco, então se você adicionar um
// serviço novo no banco ele já aparece aqui automaticamente.
$servicos = $pdo->query("SELECT id, nome, descricao FROM servicos WHERE ativo = 1 ORDER BY id")->fetchAll();

// Ícone padrão para serviços que não têm um ícone específico cadastrado.
$icones = [
    'Banho'          => 'icons/icon_b.png',
    'Tosa'           => 'icons/icon_tesoura.png',
    'Corte de unha'  => 'icons/icon_unha.png',
    'Veterinário'    => 'icons/icon_veterinario.png',
];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PetShop - Serviços</title>
    <link rel="stylesheet" href="../assets/css/base.css">
    <link rel="stylesheet" href="style1.css">
</head>
<body>

    <div class="imageP">
        <img src="modeloshop.jpg" alt="Fachada do petshop">
    </div>

    <div class="container-inicio">
        <button class="agendar" onclick="window.location.href='../pageagenda/agenda.php'">
            Agendar agora
        </button>

        <h2 class="titulo-secao">Serviços</h2>

        <div class="grade-servicos">
            <?php foreach ($servicos as $i => $servico): ?>
                <div class="servico-card">
                    <button
                        type="button"
                        class="servico-topo"
                        aria-expanded="false"
                        aria-controls="desc-<?= $i ?>"
                    >
                        <img
                            src="<?= htmlspecialchars($icones[$servico['nome']] ?? 'icons/icon_b.png') ?>"
                            alt=""
                            class="icon"
                        >
                        <span class="servico-nome"><?= htmlspecialchars($servico['nome']) ?></span>
                    </button>
                    <div class="servico-detalhe" id="desc-<?= $i ?>">
                        <div class="servico-detalhe-interno">
                            <p class="servico-desc">
                                <?= htmlspecialchars($servico['descricao'] ?: 'Consulte-nos para mais detalhes sobre este serviço.') ?>
                            </p>
                            <a class="servico-dica" href="../pageagenda/agenda.php?servico=<?= (int) $servico['id'] ?>">
                                Clique em <strong>Agendar agora</strong> para reservar &rarr;
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="info-card">
            <p class="tt">Horário de funcionamento</p>
            <p class="hr">Segunda a sábado, 8h às 18h</p>
        </div>

        <div class="info-card">
            <p class="tt">WhatsApp</p>
            <p class="hr"><img src="icons/icon_whatssap.png" alt="" width="24px"> (11) 9999-9999</p>
        </div>

        <button class="consultar-btn" onclick="window.location.href='../consulta/consulta.php'">
            Consultar meu agendamento
        </button>
    </div>

    <div class="link-admin">
        <a href="../admin/login.php">Área do administrador</a>
    </div>

    <script src="inicio.js"></script>
</body>
</html>
