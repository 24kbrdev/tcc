// Ao clicar em um serviço, abre a descrição dele (e fecha a que estava aberta).
const cards = document.querySelectorAll('.servico-card');

cards.forEach(card => {
    const botao = card.querySelector('.servico-topo');

    botao.addEventListener('click', () => {
        const vaiAbrir = !card.classList.contains('aberto');

        // Só um serviço aberto por vez, para a página não ficar poluída.
        cards.forEach(outro => {
            outro.classList.remove('aberto');
            outro.querySelector('.servico-topo').setAttribute('aria-expanded', 'false');
        });

        if (vaiAbrir) {
            card.classList.add('aberto');
            botao.setAttribute('aria-expanded', 'true');
        }
    });
});
