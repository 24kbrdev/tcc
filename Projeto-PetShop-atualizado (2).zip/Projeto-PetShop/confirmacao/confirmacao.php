<?php
session_start();

if (empty($_SESSION['ultimo_agendamento'])) {
    header('Location: ../pageinicio/index.php');
    exit;
}

$ag = $_SESSION['ultimo_agendamento'];
unset($_SESSION['ultimo_agendamento']);

$dataFormatada = date('d/m/Y', strtotime($ag['data']));
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agendamento confirmado</title>
    <link rel="stylesheet" href="../assets/css/base.css">
    <link rel="stylesheet" href="confirmacao.css">
</head>
<body>

<div class="topo">
    <h1>Agendamento confirmado! 🐾</h1>
</div>

<div class="container-flow">

    <div class="cartao-codigo">
        <p class="rotulo-codigo">Seu código de confirmação</p>
        <p class="codigo" id="codigo"><?= htmlspecialchars($ag['codigo']) ?></p>
        <button type="button" class="btn-copiar" id="botaoCopiar" onclick="copiarCodigo()">Copiar código</button>
        <p class="aviso-codigo">
            Guarde este código! Você vai precisar dele, junto com o telefone
            cadastrado, para consultar ou cancelar seu agendamento na página inicial.
        </p>
    </div>

    <div class="cartao-sucesso">
        <p><strong>Pet:</strong> <?= htmlspecialchars($ag['pet']) ?></p>
        <p><strong>Tutor:</strong> <?= htmlspecialchars($ag['tutor']) ?></p>
        <p><strong>Data:</strong> <?= $dataFormatada ?></p>
        <p><strong>Horário:</strong> <?= htmlspecialchars($ag['horario']) ?></p>
    </div>

    <button class="btn-principal ativo" onclick="window.location.href='../pageinicio/index.php'">
        Voltar ao início
    </button>
</div>

<script>
function copiarCodigo() {
    const codigo = document.getElementById('codigo').textContent.trim();
    const botao = document.getElementById('botaoCopiar');

    navigator.clipboard.writeText(codigo).then(() => {
        const textoOriginal = botao.textContent;
        botao.textContent = 'Copiado!';
        setTimeout(() => { botao.textContent = textoOriginal; }, 1800);
    });
}
</script>

</body>
</html>
